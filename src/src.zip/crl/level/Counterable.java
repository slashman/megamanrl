package crl.level;

public interface Counterable {
	public int getCounter();
}
