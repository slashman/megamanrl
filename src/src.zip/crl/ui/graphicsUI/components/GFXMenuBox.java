package crl.ui.graphicsUI.components;

import java.util.Vector;

import javax.swing.JPanel;

public class GFXMenuBox extends JPanel{

	public void setMenuItems(Vector items){
		
	}
	
	public void setPrompt(String prompt){
		
	}
		
	public Object getSelection(){
		return null;
	}

	public void setTitle(String title){
		
	}
}
