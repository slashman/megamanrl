package crl.ui.graphicsUI.components;

import crl.player.Player;

public class GFXInventoryBox extends GFXMenuBox{
	private Player player;
	public GFXInventoryBox(Player p){
		player = p;
	}
	

}
