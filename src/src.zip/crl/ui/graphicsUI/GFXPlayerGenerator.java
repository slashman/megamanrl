package crl.ui.graphicsUI;

import java.awt.Color;

import javax.swing.JTextArea;

import sz.util.ScriptUtil;
import sz.util.Util;
import crl.game.PlayerGenerator;
import crl.player.Player;
import crl.ui.AppearanceFactory;
import crl.ui.Display;

public class GFXPlayerGenerator extends PlayerGenerator{
	public GFXPlayerGenerator(SwingSystemInterface si){
		this.si = si;
		txtClassDescription = new JTextArea();
		txtClassDescription.setOpaque(false);
		txtClassDescription.setForeground(Color.WHITE);
		txtClassDescription.setVisible(false);
		txtClassDescription.setBounds(345, 162, 302, 84);
		txtClassDescription.setLineWrap(true);
		txtClassDescription.setWrapStyleWord(true);
		txtClassDescription.setFocusable(false);
		txtClassDescription.setEditable(false);
		txtClassDescription.setFont(GFXDisplay.FNT_TEXT);
		
		si.add(txtClassDescription);
	}
	private SwingSystemInterface si;
	private JTextArea txtClassDescription;
	
	private String IMG_GENERATOR = "gfx/barrett-moon.gif";
	private String IMG_FLAME = "gfx/barrett-picker.gif";
	
	public Player generatePlayer(){
		si.drawImage(IMG_GENERATOR);
		si.printAtPixel(69,86,"CHOOSE YOUR DESTINY", GFXDisplay.COLOR_BOLD);
		si.getGraphics2D().setColor(Color.DARK_GRAY);
		si.getGraphics2D().fillRect(70,94,661,3);
		si.refresh();
		si.printAtPixel(69,118,"Hero Name:", Color.WHITE); 
		String name = si.input(143,118,GFXDisplay.COLOR_BOLD, 10);
		si.printAtPixel(69,133, "Sex: [m/f]", Color.WHITE);
		si.refresh();
		CharKey x = new CharKey(CharKey.NONE);
		while ( x.code != CharKey.M &&
				x.code != CharKey.m &&
				x.code != CharKey.F &&
				x.code != CharKey.f)
			x = si.inkey();
		int sex = 0;
		if (x.code == CharKey.M || x.code == CharKey.m)
			sex = Player.MALE;
		else
			sex = Player.FEMALE;
		si.printAtPixel(138,133, x.toString(), GFXDisplay.COLOR_BOLD);
		
		
        
        si.printAtPixel(350,260, "Attack      ", GFXDisplay.COLOR_BOLD);
        si.printAtPixel(350,280, "Soul Power  ", GFXDisplay.COLOR_BOLD);
        si.printAtPixel(350,300, "Resistance  ", GFXDisplay.COLOR_BOLD);
        si.printAtPixel(350,320, "Evasion     ", GFXDisplay.COLOR_BOLD);
        si.printAtPixel(350,340,"Movement    ", GFXDisplay.COLOR_BOLD);
        si.printAtPixel(350,360,"Combat      ", GFXDisplay.COLOR_BOLD);
        si.printAtPixel(350,380,"Invokation  ", GFXDisplay.COLOR_BOLD);
        si.printAtPixel(350,400,"Strength    ", GFXDisplay.COLOR_BOLD);
        si.printAtPixel(350,420,"Sight       ", GFXDisplay.COLOR_BOLD);
        si.printAtPixel(350,440,"Wealth      ", GFXDisplay.COLOR_BOLD);
        txtClassDescription.setVisible(true);
    	x = new CharKey(CharKey.NONE);
    	int choice = 0;
    	si.saveBuffer();
    	while (true){
    		si.restore();
    	
	        si.refresh();
    		while ( x.code != CharKey.UARROW && x.code != CharKey.DARROW && x.code != CharKey.SPACE && x.code != CharKey.ENTER)
				x = si.inkey();
			if (x.code == CharKey.UARROW){
				if (choice > 0) {
					choice--;
				}
			} else if (x.code == CharKey.DARROW){
				if (choice < 5) {
					choice++;
				}
			} else 
				break;
			
	        x.code = CharKey.NONE;
    	}
    	//si.remove(txtClassDescription);
    	txtClassDescription.setVisible(false);
    	return getPlayer(name);
	}
}