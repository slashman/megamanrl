package crl.item.weapon;

public class BaseWeapon {

}
