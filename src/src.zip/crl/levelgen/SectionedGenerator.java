package crl.levelgen;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import sz.util.Position;
import sz.util.Util;
import crl.level.LevelInfo;
import crl.levelgen.patterns.BombManStage;
import crl.levelgen.patterns.CutManStage;
import crl.levelgen.patterns.FireManStage;

public class SectionedGenerator {
	public static SectionedGenerator thus = new SectionedGenerator();
	
	public SectionedGenerator(){
		initialize();
	}
	
	private ArrayList<LevelInfo> levelsInfo = new ArrayList<LevelInfo>();
	public ArrayList<LevelInfo> getLevelsInfo (){
		return levelsInfo;
	}
	
	public void addLevelInfo(LevelInfo l){
		levelsInfo.add(l);
	}
	
	public XLevelMetaData generateStructure(String levelId){
		LevelSectionInfo info = null;
		XLevelMetaData ret = new XLevelMetaData();
		ArrayList<LevelSectionInfo> prelist = new ArrayList<LevelSectionInfo>();
		ret.setSections(prelist);
		info = new LevelSectionInfo();
		if (levelId.equals("BOMBMAN")){
			info.setFeature(readFeature(levelId, "start"));
			info.setPosition(new Position(0, 0));
			prelist.add(info);
			int currentX = 0;
			int currentY = 0;
			int segments = 20;
			int currentDirection = LEFT_TO_RIGHT;
			LevelFeature currentFeature = null;
			int currentSegments = 0;
			//for (int i = 0; i < segments; i++){
			boolean finish = false;
			while (!finish){
				currentSegments++;
				switch (currentDirection){
				case LEFT_TO_RIGHT:
					if (currentSegments > segments){
						currentFeature = readFeature(levelId, "cyan_gate");
						finish = true;
					} else if (Util.chance(30)){
						currentDirection = LEFT_TO_UP;
						currentFeature = readFeature(levelId, "cyan_l_u");
					} else {
						currentFeature = readFeature(levelId, "cyan_l_r");
					}
					currentX++;
					
					break;
				case LEFT_TO_UP:
					currentDirection = DOWN_TO_UP;
					currentY--;
					currentFeature = readFeature(levelId, "cyan_d_u");
					break;
				case DOWN_TO_UP:
					if (Util.chance(30)){
						currentDirection = DOWN_TO_RIGHT;
						currentFeature = readFeature(levelId, "cyan_d_r");
					} else {
						currentFeature = readFeature(levelId, "cyan_d_u");
					}
					currentY--;
					
					break;
				case DOWN_TO_RIGHT:
					currentDirection = LEFT_TO_RIGHT;
					currentFeature = readFeature(levelId, "cyan_l_r");
					currentX++;
					break;
				}
				
				info = new LevelSectionInfo();
				info.setFeature(currentFeature);
				info.setPosition(new Position(currentX, currentY));
				prelist.add(info);
			}
			currentFeature = readFeature(levelId, "bombmanLair_l_d");
			currentX++;
			info = new LevelSectionInfo();
			info.setFeature(currentFeature);
			info.setPosition(new Position(currentX, currentY));
			prelist.add(info);
			
			currentFeature = readFeature(levelId, "bombmanLair_u_d");
			currentY++;
			info = new LevelSectionInfo();
			info.setFeature(currentFeature);
			info.setPosition(new Position(currentX, currentY));
			prelist.add(info);
			
			currentFeature = readFeature(levelId, "bombmanLair_u_d");
			currentY++;
			info = new LevelSectionInfo();
			info.setFeature(currentFeature);
			info.setPosition(new Position(currentX, currentY));
			prelist.add(info);
			
			currentFeature = readFeature(levelId, "bombmanLair");
			currentY++;
			info = new LevelSectionInfo();
			info.setFeature(currentFeature);
			info.setPosition(new Position(currentX, currentY));
			prelist.add(info);
			
			
			ret.setBase(ret.normalize(20,12));
			ret.setCharmap(BombManStage.defaultCharMap);
			return ret;
		} else if (levelId.equals("CUTMAN") || levelId.equals("FIREMAN")){
			info.setFeature(readFeature(levelId, "start"));
			info.setPosition(new Position(0, 0));
			prelist.add(info);
			int currentX = 0;
			int currentY = 0;
			int segments = 20;
			int currentDirection = LEFT_TO_RIGHT;
			LevelFeature currentFeature = null;
			int currentSegments = 0;
			//for (int i = 0; i < segments; i++){
			boolean finish = false;
			while (!finish){
				currentSegments++;
				switch (currentDirection){
				case LEFT_TO_RIGHT:
					if (currentSegments > segments){
						currentFeature = readFeature(levelId, "cyan_gate");
						finish = true;
					} else if (Util.chance(30)){
						if (Util.chance(50)){
							currentDirection = LEFT_TO_UP;
							currentFeature = readFeature(levelId, "cyan_l_u");
						} else {
							currentDirection = LEFT_TO_DOWN;
							currentFeature = readFeature(levelId, "cyan_l_d");
						}
						
					} else {
						currentFeature = readFeature(levelId, "cyan_l_r");
					}
					currentX++;
					
					break;
				case LEFT_TO_UP:
					currentDirection = DOWN_TO_UP;
					currentY--;
					currentFeature = readFeature(levelId, "cyan_d_u");
					break;
				case LEFT_TO_DOWN:
					currentDirection = UP_TO_DOWN;
					currentY++;
					currentFeature = readFeature(levelId, "cyan_u_d");
					break;
				case DOWN_TO_UP:
					if (Util.chance(30)){
						currentDirection = DOWN_TO_RIGHT;
						currentFeature = readFeature(levelId, "cyan_d_r");
					} else {
						currentFeature = readFeature(levelId, "cyan_d_u");
					}
					currentY--;
					
					break;
				case DOWN_TO_RIGHT:
					currentDirection = LEFT_TO_RIGHT;
					currentFeature = readFeature(levelId, "cyan_l_r");
					currentX++;
					break;
				case UP_TO_DOWN:
					if (Util.chance(30)){
						currentDirection = UP_TO_RIGHT;
						currentFeature = readFeature(levelId, "cyan_u_r");
					} else {
						currentFeature = readFeature(levelId, "cyan_u_d");
					}
					currentY++;
					break;
				case UP_TO_RIGHT:
					currentDirection = LEFT_TO_RIGHT;
					currentFeature = readFeature(levelId, "cyan_l_r");
					currentX++;
					break;
				}
				
				info = new LevelSectionInfo();
				info.setFeature(currentFeature);
				info.setPosition(new Position(currentX, currentY));
				prelist.add(info);
			}
			currentFeature = readFeature(levelId, "cutmanLair_l_r");
			currentX++;
			info = new LevelSectionInfo();
			info.setFeature(currentFeature);
			info.setPosition(new Position(currentX, currentY));
			prelist.add(info);
			
			currentFeature = readFeature(levelId, "cutmanLair_l_r");
			currentX++;
			info = new LevelSectionInfo();
			info.setFeature(currentFeature);
			info.setPosition(new Position(currentX, currentY));
			prelist.add(info);
			
			currentFeature = readFeature(levelId, "cutmanLair");
			currentX++;
			info = new LevelSectionInfo();
			info.setFeature(currentFeature);
			info.setPosition(new Position(currentX, currentY));
			prelist.add(info);
			
			
			ret.setBase(ret.normalize(20,12));
			if (levelId.equals("FIREMAN")){
				ret.setCharmap(FireManStage.defaultCharMap);
			} else {
				ret.setCharmap(CutManStage.defaultCharMap);
			}
			return ret;
		}
		
		return null;
	}
	
	private final static int LEFT_TO_RIGHT = 0;
	private final static int LEFT_TO_UP = 1;
	private final static int DOWN_TO_UP = 2;
	private final static int DOWN_TO_RIGHT = 3;
	private final static int LEFT_TO_DOWN = 4;
	private final static int UP_TO_DOWN = 5;
	private final static int UP_TO_RIGHT = 6;
	
	public static void main (String[] args){
		XLevelMetaData xlmd = thus.generateStructure("CUTMAN");
		ArrayList<LevelSectionInfo> s = xlmd.getSections();
		for (LevelSectionInfo info: s){
			System.out.println(info.getFeature() + " at "+info.getPosition().toString());
		}
	}
	
	public LevelFeature readFeature(String levelId, String featureId){
		return levels.get(levelId).get(featureId);
	}
	
	private Hashtable<String, Hashtable<String, LevelFeature>> levels = new Hashtable<String, Hashtable<String, LevelFeature>>(); 
	public void initialize(){
		try {
			File file = new File("data/levels.xml");
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(file);
			doc.getDocumentElement().normalize();
			NodeList levelNodes = doc.getElementsByTagName("level");
			for (int s = 0; s < levelNodes.getLength(); s++) {
				Node levelNode = levelNodes.item(s);
				
				if (levelNode.getNodeType() == Node.ELEMENT_NODE) {
					Element levelElement = (Element) levelNode;
					LevelInfo li = new LevelInfo();
					li.setName (levelElement.getAttribute("name"));
					li.setPic1 (levelElement.getAttribute("pic1"));
					li.setPic2 (levelElement.getAttribute("pic2"));
					li.setPic3 (levelElement.getAttribute("pic3"));
					li.setPic4 (levelElement.getAttribute("pic4"));
					li.setPic5 (levelElement.getAttribute("pic5"));
					li.setId(levelElement.getAttribute("id"));
					li.setColor(Integer.parseInt(levelElement.getAttribute("color")));
					levelsInfo.add(li);
					Hashtable<String, LevelFeature> levelFeatures = new Hashtable<String, LevelFeature>();
					String levelId = levelElement.getAttribute("id");
					NodeList segmentNodes = levelElement.getElementsByTagName("segment");
					for (int t = 0; t < segmentNodes.getLength(); t++) {
						Node segmentNode = segmentNodes.item(t);
						
						if (segmentNode.getNodeType() == Node.ELEMENT_NODE) {
							Element segmentElement = (Element) segmentNode;
							LevelFeature feature = new LevelFeature();
							String featureId = segmentElement.getAttribute("id");
							NodeList patternNodes = segmentElement.getElementsByTagName("pattern");
							for (int u = 0; u < patternNodes.getLength(); u++) {
								Node patternNode = patternNodes.item(u);
								ArrayList<String> rowsArrayList = new ArrayList<String>();
								if (patternNode.getNodeType() == Node.ELEMENT_NODE) {
									Element patternElement = (Element) patternNode;
									NodeList rowNodes = patternElement.getElementsByTagName("r");
									for (int v = 0; v < rowNodes.getLength(); v++) {
										String line = rowNodes.item(v).getTextContent();
										//System.out.println(line);
										rowsArrayList.add(line);
									}
								}
								feature.addLayout(rowsArrayList);
							}
							levelFeatures.put(featureId, feature);
						}
					}
					levels.put(levelId, levelFeatures);
				}
			}
		} catch (DOMException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}



