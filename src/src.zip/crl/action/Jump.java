package crl.action;

import crl.actor.Actor;
import crl.level.Cell;
import crl.player.Player;

public class Jump extends HeartAction{
	private int height;
	 
	public String getID(){
		return "Jump";
	}
	
	public Jump(int height) {
		this.height = height;
	}
	
	public String getInvalidationMessage(){
		return "You can't jump on midair!";
	}
	
	public boolean canPerform(Actor a) {
		if (!super.canPerform(a))
			return false;
		if (a.isFlying())
			return true;
   		Cell currentCell = a.getStandingCell();
   		return currentCell != null && currentCell.isSolid() && !currentCell.isStair();
   	}

	public String getSFX(){
		if (performer instanceof Player){
			Player p = (Player) performer;
			if (p.getSex() == Player.MALE){
				return "wav/jump_male.wav";
			} else {
				return "wav/jump_female.wav";
			}
		} else 
			return null;
		
	}

	public int getCost(){
		return 0;
	}

	public void execute(){
		super.execute();
		performer.setCounter("JUMPING", height);
	}
	
	@Override
	public int getHeartCost() {
		return 5;
	}
}
