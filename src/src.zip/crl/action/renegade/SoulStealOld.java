package crl.action.renegade;

import sz.util.Line;
import sz.util.Position;
import crl.action.Action;
import crl.actor.Actor;
import crl.feature.Feature;
import crl.level.Cell;
import crl.level.Level;
import crl.monster.Monster;
import crl.player.Player;
import crl.ui.effects.EffectFactory;

public class SoulStealOld extends Action{
	public String getID(){
		return "SoulSteal";
	}
	
	public boolean needsPosition(){
		return true;
	}
	
	public String getSFX(){
		return "wav/alu_soul.wav";
	}

	public void execute(){
        Level aLevel = performer.getLevel();
        Player aPlayer = aLevel.getPlayer();
        if (aPlayer.getHearts() < 10){
        	invalidationMessage = "Not enough hearts.";
	        return;
	    }
	    aPlayer.reduceHearts(10);
	    if (targetPosition.equals(performer.getPosition())){
        	aLevel.addMessage("The soul revitalizes you!");
        	aPlayer.recoverHits(2);
        	return;
        }
	    Line aLine = new Line (aPlayer.getPosition(), targetPosition);
		for (int i=0; i<20; i++){
			Position destinationPoint = aLine.next();

			Feature destinationFeature = aLevel.getFeatureAt(destinationPoint);
        	if (destinationFeature != null && destinationFeature.isDestroyable()){
	        	aLevel.addMessage("The "+destinationFeature.getDescription()+" has no soul");
				return;
			}

			Monster targetMonster = performer.getLevel().getMonsterAt(destinationPoint);
			Cell destinationCell = performer.getLevel().getMapCell(destinationPoint);

			if (
				targetMonster != null &&
				!(targetMonster.isInWater() && targetMonster.canSwim()) &&
				(destinationCell.getHeight() == aLevel.getMapCell(aPlayer.getPosition()).getHeight() ||
				destinationCell.getHeight() -1  == aLevel.getMapCell(aPlayer.getPosition()).getHeight() ||
				destinationCell.getHeight() == aLevel.getMapCell(aPlayer.getPosition()).getHeight()-1)
			){
				if (targetMonster.wasSeen())
					aLevel.addMessage("You steal the "+targetMonster.getDescription()+" soul");
				drawEffect(EffectFactory.getSingleton().createDirectedEffect(aPlayer.getPosition(), targetPosition, "SFX_SOUL_STEAL", i));
				targetMonster.damage(2+aPlayer.getSoulPower()*3);
				aLevel.getPlayer().recoverHits(1);
				return;
			}
		}
		drawEffect(EffectFactory.getSingleton().createDirectedEffect(aPlayer.getPosition(), targetPosition, "SFX_SOUL_STEAL", 20));
	}

	public int getCost(){
		Player p = (Player) performer;
		return (int)(p.getCastCost() * 1.3);
	}
	
	public String getPromptPosition(){
		return "Where do you want to summon the spirit?";
	}
	
	public boolean canPerform(Actor a){
		Player aPlayer = (Player) a;
        Level aLevel = performer.getLevel();
        if (aPlayer.getHearts() < 10){
            aLevel.addMessage("You need more energy!");
            return false;
		}
        return true;
	}
}