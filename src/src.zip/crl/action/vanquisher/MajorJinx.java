package crl.action.vanquisher;

import crl.action.Action;
import crl.actor.Actor;
import crl.level.Level;
import crl.player.Player;

public class MajorJinx extends Action{
	public String getID(){
		return "MAJOR_JINX";
	}
	
	public String getSFX(){
		return null;
	}
	
	public int getCost(){
		Player p = (Player) performer;
		return (int)(p.getCastCost() * 1.1);
	}
	
	public void execute(){
		Player aPlayer = (Player)performer;
		Level aLevel = aPlayer.getLevel();
		aPlayer.selfDamage(Player.DAMAGE_JINX, 5);
		aPlayer.addHearts(5+aPlayer.getSoulPower()*2);
		aLevel.addMessage("You exchange vitality for power!!");
	}
	
	public boolean canPerform(Actor a){
		Player aPlayer = (Player) a;
        Level aLevel = performer.getLevel();
        if (aPlayer.getHits() <= 5){
            aLevel.addMessage("That would be suicidal!");
            return false;
		}
        return true;
	}
}