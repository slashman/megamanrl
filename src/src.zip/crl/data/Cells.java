package crl.data;

import crl.level.Cell;
import crl.ui.AppearanceFactory;

public class Cells {
	public static Cell [] getCellDefinitions(AppearanceFactory apf){
		Cell [] ret = new Cell [23];
		/*Town*/
		ret [0] = new Cell("METAL_BLOCK", "metal block", "Metal Block", apf.getAppearance("METAL_BLOCK"), true, true);
		ret [1] = new Cell("METAL_BGROUND", "", "", apf.getAppearance("METAL_BGROUND"), false, false);
		ret [2] = new Cell("METAL_STAIR", "metal stairs", "Metal Stairs", apf.getAppearance("METAL_STAIR"), false, false); ret[2].setIsStair(true);
		ret [3] = new Cell("METAL_MOUND", "metal block", "Metal Block", apf.getAppearance("METAL_MOUND"), true, false); ret[3].setRound(true);
		
		ret [4] = new Cell("CYANSKY_BGROUND", "", "", apf.getAppearance("CYANSKY_BGROUND"), false, false);
		ret [5] = new Cell("CONCRETEFLOOR", "concrete floor", "Concrete floor", apf.getAppearance("CONCRETEFLOOR"), true, false);
		ret [6] = new Cell("CONCRETETOWER", "concrete tower", "Concrete tower", apf.getAppearance("CONCRETETOWER"), true, false);
		ret [14] = new Cell("CONCRETETOWER2", "concrete tower", "Concrete tower", apf.getAppearance("CONCRETETOWER2"), true, false);
		ret [7] = new Cell("CONCRETESTAIRS", "concrete stairs", "Concrete stairs", apf.getAppearance("CONCRETESTAIRS"), false, false); ret[7].setIsStair(true);
		ret [8] = new Cell("CONESPIKE", "cone spike", "Cone Spike", apf.getAppearance("CONESPIKE"), true, false); ret[8].setSpike(true);
		
		ret [9] = new Cell("PIPESWALL", "pipes wall", "Pipes Wall", apf.getAppearance("PIPESWALL"), true, false);
		ret [10] = new Cell("WILYLOGO", "Dr. W. Logo", "Dr. W. Logo", apf.getAppearance("WILYLOGO"), true, false);
		ret [11] = new Cell("BOSSDOOR", "Boss door", "Boss Door", apf.getAppearance("BOSSDOOR"), false, true);
		ret [12] = new Cell("GREENBRICK_BGROUND", "", "", apf.getAppearance("GREENBRICK_BGROUND"), false, false);
		ret [13] = new Cell("BLACKNESS", "", "", apf.getAppearance("BLACKNESS"), true, true);
		
		ret [15] = new Cell("GRAY_BGROUND", "", "", apf.getAppearance("GRAY_BGROUND"), false, false);
		ret [16] = new Cell("GREEN_BRICK", "concrete floor", "Concrete floor", apf.getAppearance("GREEN_BRICK"), true, false);
		ret [17] = new Cell("BUNKER", "", "", apf.getAppearance("BUNKER"), false, false);
		ret [18] = new Cell("GRAY_METAL_BGROUND", "", "", apf.getAppearance("GRAY_METAL_BGROUND"), false, false);
		
		ret [19] = new Cell("BLACK_BGROUND", "", "", apf.getAppearance("BLACK_BGROUND"), false, false);
		ret [20] = new Cell("ORANGE_BGROUND", "", "", apf.getAppearance("ORANGE_BGROUND"), false, false);
		ret [21] = new Cell("METAL_BRICK", "metal floor", "Metal floor", apf.getAppearance("METAL_BRICK"), true, false);
		ret [22] = new Cell("LAVA", "", "", apf.getAppearance("LAVA"), false, false);
		return ret;
	}

}
