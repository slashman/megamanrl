package crl.conf.console.data;
import sz.csi.ConsoleSystemInterface;
import crl.level.Cell;
import crl.ui.*;
import crl.ui.consoleUI.CharAppearance;

public class CharAppearances {
	private Appearance [] defs = new Appearance[]{
		new CharAppearance("METAL_BLOCK", '#', ConsoleSystemInterface.GRAY),
        new CharAppearance("METAL_BGROUND", '.', ConsoleSystemInterface.BLUE),
        new CharAppearance("METAL_STAIR", '=', ConsoleSystemInterface.WHITE),
        new CharAppearance("METAL_MOUND", '^', ConsoleSystemInterface.GRAY),
        
        new CharAppearance("CYANSKY_BGROUND", ':', ConsoleSystemInterface.CYAN),
        new CharAppearance("CONCRETEFLOOR", '#', ConsoleSystemInterface.WHITE),
        new CharAppearance("CONCRETETOWER", '#', ConsoleSystemInterface.BLUE),
        new CharAppearance("CONCRETETOWER2", '%', ConsoleSystemInterface.DARK_BLUE),
        new CharAppearance("CONCRETESTAIRS", '=', ConsoleSystemInterface.BLUE),
        new CharAppearance("CONESPIKE", '^', ConsoleSystemInterface.WHITE),
        
        new CharAppearance("PIPESWALL", '>', ConsoleSystemInterface.WHITE),
        new CharAppearance("WILYLOGO", 'W', ConsoleSystemInterface.WHITE),
        new CharAppearance("BOSSDOOR", ']', ConsoleSystemInterface.WHITE),
        new CharAppearance("GREENBRICK_BGROUND", ',', ConsoleSystemInterface.GREEN),
        new CharAppearance("BLACKNESS", ' ', ConsoleSystemInterface.BLACK),
        
        new CharAppearance("GRAY_BGROUND", ':', ConsoleSystemInterface.GRAY),
        new CharAppearance("GREEN_BRICK", '#', ConsoleSystemInterface.GREEN),
        new CharAppearance("BUNKER", '&', ConsoleSystemInterface.GRAY),
        new CharAppearance("GRAY_METAL_BGROUND", '-', ConsoleSystemInterface.GRAY),
				
        
        new CharAppearance("KAMADOMA_RED", 'k', ConsoleSystemInterface.RED),
        new CharAppearance("BOMBOMBOMB_BLUE", '0', ConsoleSystemInterface.BLUE),
        new CharAppearance("BOMBOMBOMBBOMB", '*', ConsoleSystemInterface.BLUE),
        new CharAppearance("SUZYBOT", 'X', ConsoleSystemInterface.RED),
        new CharAppearance("BLASTER", 'E', ConsoleSystemInterface.BROWN),
        new CharAppearance("ENEMYSHOT", 'o', ConsoleSystemInterface.WHITE),
        new CharAppearance("PLASMASHOT", 'o', ConsoleSystemInterface.WHITE),
        new CharAppearance("BOMBMANBOMB", '�', ConsoleSystemInterface.RED),
        new CharAppearance("GABYOALL", 'v', ConsoleSystemInterface.RED),
        new CharAppearance("KILLERBOMB", '<', ConsoleSystemInterface.GRAY),
        new CharAppearance("MAMBU", 'O', ConsoleSystemInterface.BLUE),
        
        new CharAppearance("ROLLING_CUTTER", '>', ConsoleSystemInterface.WHITE),
        
        new CharAppearance("MEGAMAN", '@', ConsoleSystemInterface.BLUE),
        new CharAppearance("BOMBMAN", '�', ConsoleSystemInterface.BROWN),
        new CharAppearance("CUTMAN", 'V', ConsoleSystemInterface.WHITE),
        
        new CharAppearance("PLASMA_BUSTER_C", '$', ConsoleSystemInterface.CYAN),
        new CharAppearance("LASER_BUSTER_C", '%', ConsoleSystemInterface.CYAN),
        new CharAppearance("SLASH_BUSTER_C", '/', ConsoleSystemInterface.CYAN),
        new CharAppearance("PLASMA_BUSTER_M", '$', ConsoleSystemInterface.MAGENTA),
        new CharAppearance("LASER_BUSTER_M", '%', ConsoleSystemInterface.MAGENTA),
        new CharAppearance("SLASH_BUSTER_M", '/', ConsoleSystemInterface.MAGENTA),
        new CharAppearance("PLASMA_BUSTER_Y", '$', ConsoleSystemInterface.YELLOW),
        new CharAppearance("LASER_BUSTER_Y", '%', ConsoleSystemInterface.YELLOW),
        new CharAppearance("SLASH_BUSTER_Y", '/', ConsoleSystemInterface.YELLOW),
        new CharAppearance("PLASMA_BUSTER_K", '$', ConsoleSystemInterface.GRAY),
        new CharAppearance("LASER_BUSTER_K", '%', ConsoleSystemInterface.GRAY),
        new CharAppearance("SLASH_BUSTER_K", '/', ConsoleSystemInterface.GRAY),
        new CharAppearance("CUTTER", '>', ConsoleSystemInterface.RED),
        
        new CharAppearance("BUSTER", '%', ConsoleSystemInterface.BLUE),

        new CharAppearance("ENERGYTANK", 'E', ConsoleSystemInterface.BLUE),
		new CharAppearance("ENERGYPELLET", 'o', ConsoleSystemInterface.BLUE),
		new CharAppearance("BIGENERGYPELLET", '0', ConsoleSystemInterface.BLUE),
		new CharAppearance("WEAPONENERGY", 'o', ConsoleSystemInterface.PURPLE),
		new CharAppearance("HYPERBOMB", 'B', ConsoleSystemInterface.RED),
		new CharAppearance("HYPERBOMBBOMB", '�', ConsoleSystemInterface.RED),
		
		new CharAppearance("BLACK_BGROUND", ' ', ConsoleSystemInterface.BLACK),
		new CharAppearance("ORANGE_BGROUND", ':', ConsoleSystemInterface.BROWN),
		new CharAppearance("METAL_BRICK", '#', ConsoleSystemInterface.GRAY),
		new CharAppearance("LAVA", '~', ConsoleSystemInterface.RED),
        };

	public Appearance[] getAppearances() {
		return defs;
	}
}